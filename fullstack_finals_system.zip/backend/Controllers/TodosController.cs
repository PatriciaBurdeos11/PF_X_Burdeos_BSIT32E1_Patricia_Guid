
using Microsoft.AspNetCore.Mvc;
using backend.Models;

namespace backend.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TodosController : ControllerBase
    {
        private static List<Todo> todos = new();

        [HttpGet]
        public IActionResult Get() => Ok(todos);

        [HttpPost]
        public IActionResult Post(Todo todo)
        {
            todo.Id = Guid.NewGuid();
            todos.Add(todo);
            return Ok(todo);
        }

        [HttpDelete("{id}")]
        public IActionResult Delete(Guid id)
        {
            var todo = todos.FirstOrDefault(t => t.Id == id);
            if (todo == null) return NotFound();
            todos.Remove(todo);
            return NoContent();
        }
    }
}

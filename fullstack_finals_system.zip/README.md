
FULL STACK TODO SYSTEM

FRONTEND:
cd frontend
npm install
npm run dev

BACKEND:
Create ASP.NET Web API project
Replace Controllers and Models with provided files
Run backend on localhost:5000

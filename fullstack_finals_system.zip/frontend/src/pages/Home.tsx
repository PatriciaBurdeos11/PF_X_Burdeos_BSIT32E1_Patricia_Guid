
import { useState, useEffect } from "react";

export default function Home(){
  const [todos,setTodos]=useState<any[]>([]);
  const [title,setTitle]=useState("");

  const fetchTodos = async()=>{
    const res = await fetch("http://localhost:5000/api/todos");
    const data = await res.json();
    setTodos(data);
  }

  const addTodo = async()=>{
    await fetch("http://localhost:5000/api/todos",{
      method:"POST",
      headers:{"Content-Type":"application/json"},
      body: JSON.stringify({title, completed:false})
    });
    setTitle("");
    fetchTodos();
  }

  const deleteTodo = async(id:string)=>{
    await fetch(`http://localhost:5000/api/todos/${id}`,{method:"DELETE"});
    fetchTodos();
  }

  useEffect(()=>{ fetchTodos(); },[]);

  return (
    <div>
      <h1>Todo App</h1>
      <input value={title} onChange={e=>setTitle(e.target.value)} />
      <button onClick={addTodo}>Add</button>
      <ul>
        {todos.map(todo=>(
          <li key={todo.id}>
            {todo.title}
            <button onClick={()=>deleteTodo(todo.id)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  )
}
